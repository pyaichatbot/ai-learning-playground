# Artifact Gates

Use this reference when turning onboarding/onboard-lite into concrete comic
panels. The key move is to make `project-manifest.yml` visible at each gate.

## Gate Model

| Gate | Comic Decision | Primary Artifact | What To Show In PPT |
|---|---|---|---|
| G0 Intake | Should this initiative enter AI-assisted SDLC? | `project-manifest.yml` | project identity, owner, scenario, criticality |
| G1 Context | What does the agent need to know before acting? | `project-knowledge.yml` | domains, systems, constraints, vocabulary, dependencies |
| G2 Risk | What governance path applies? | `project-manifest.yml` | risk class, data sensitivity, human approval, audit needs |
| G3 Architecture | What boundaries must agents respect? | ADRs, architecture docs, manifest links | decision records, service boundaries, data flows |
| G4 Agent Model | Which agents/subagents may execute which work? | subagent catalog, prompt pack, command catalog | roles, allowed actions, handoff rules |
| G5 Evidence | What proof is required before merge/release? | test/eval/security reports linked in manifest | tests, scans, evals, review evidence |
| G6 Release | Who approves production movement? | release checklist, manifest approvals | release owner, exceptions, rollback, signoff |
| G7 Scale | Can the pattern be reused across teams? | adoption playbook, metrics dashboard | reusable template, KPIs, lessons learned |

## Manifest Fields To Surface

Use real project fields when available. If unavailable, show a short illustrative
snippet and label it "example".

```yaml
project:
  id: payments-modernization
  scenario: migration
  owner: product-platform
  criticality: high

ai_sdlc:
  onboarding_mode: onboard-lite
  current_gate: G2-risk
  framework_owner: ai-sdlc-poc

risk:
  classification: high
  data_sensitivity: confidential
  human_approval_required: true
  audit_trail_required: true

architecture:
  decision_records:
    - adr/001-domain-slice.md
  boundaries:
    - no direct production data access by agents
    - changes scoped to approved migration slice

agents:
  allowed:
    - codex
    - claude
    - github-copilot
  subagents:
    - architecture-reviewer
    - test-writer
    - migration-planner

evidence:
  required:
    - unit_tests
    - integration_tests
    - security_review
    - architecture_review
  status: pending
```

## `project-knowledge.yml` Fields To Surface

```yaml
knowledge:
  business_context:
    - why the system exists
    - critical user journeys
  system_context:
    - architecture overview
    - dependencies
    - integration contracts
  constraints:
    - regulatory requirements
    - data handling limits
    - latency/reliability expectations
  vocabulary:
    - domain terms
    - acronyms
    - team-specific conventions
```

## Slide Pattern: Manifest Gate

Use this pattern when stakeholders worry the framework is abstract:

```text
Left: comic panel showing the team debating the decision.
Right: editable YAML card showing the manifest fields updated by that gate.
Footer: "Decision is not complete until the manifest is updated and evidence-linked."
```

## Recommended Artifacts To Add If Missing

If framework review finds gaps, recommend these additions:

- `project-manifest.yml` schema;
- `project-knowledge.yml` schema;
- gate checklist per onboarding mode;
- manifest update command;
- manifest validation command;
- artifact index page;
- subagent responsibility matrix;
- evidence link convention;
- exception/waiver record;
- POC escalation path.

## Onboarding vs Onboard-Lite

Use `onboarding` for high-risk, regulated, migration, or production-impacting
work. Use `onboard-lite` for low-risk pilots, demos, learning, or bounded
internal automation.

Even onboard-lite should produce:

- `project-manifest.yml`;
- `project-knowledge.yml`;
- risk classification;
- owner and approver;
- allowed agent/tool list;
- evidence expectations.
