# Image Generation

Use this reference when generating panel art.

## Model

Prefer `gpt-image-2` when available. If the local image CLI or API only supports
another model, use the best available model and state the substitution.

Generate images without readable text. All dialogue, YAML, labels, and artifact
names must be added in PowerPoint as editable shapes.

## Base Prompt

```text
Enterprise graphic novel panel for a PowerPoint walkthrough.

Scene:
[one concrete business/SDLC decision moment]

Characters:
Consistent corporate team:
- Product Owner, South Asian woman, navy blazer
- AI Architect, Black woman, burgundy blazer
- Engineering Lead, light-skinned man, teal shirt and charcoal jacket
- Risk Stakeholder, Middle Eastern man, dark plum suit

Style:
Modern enterprise graphic novel, semi-realistic, premium consulting deck quality,
financial-services technology environment, polished lighting, credible corporate tone.

Composition:
Wide 16:9 panel, characters waist-up, clear foreground/background depth,
clean negative space at top for editable PowerPoint speech bubbles.

Constraints:
No logos, no vendor marks, no readable text, no speech bubble text, no watermark,
no childish cartoon style, no stock-photo look, no fake UI copy.
```

## Scene Variations

Use these environment cues:

- executive boardroom for problem framing;
- architecture room for manifest and dependency mapping;
- delivery control room for CI/evidence gates;
- risk review room for governance and approvals;
- stakeholder briefing room for outcomes.

## Negative Prompt Ideas

Include when outputs look weak:

```text
Avoid: childish cartoon, superhero comic, meme style, neon cyberpunk, fake logos,
busy unreadable dashboards, exaggerated faces, stock photo, plastic 3D render,
watermarks, text artifacts, distorted hands.
```

## Output QA

Reject or regenerate panels when:

- characters are not credible for enterprise setting;
- in-image text is prominent or misleading;
- vendor logos appear;
- composition leaves no room for bubbles;
- scene does not visibly support the decision;
- style shifts too much across panels.

## Prompt JSONL Job Shape

```json
{
  "prompt": "Enterprise graphic novel panel... [full prompt]",
  "use_case": "illustration-story",
  "size": "1536x1024",
  "quality": "high",
  "output_format": "png",
  "model": "gpt-image-2"
}
```

If a batch interface does not accept `model` per row, pass the model at command
level or document the model used.
