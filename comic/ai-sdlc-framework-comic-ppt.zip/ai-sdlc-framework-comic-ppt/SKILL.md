---
name: ai-sdlc-framework-comic-ppt
description: Generate enterprise-grade comic PowerPoint walkthroughs for an agent-agnostic AI SDLC framework across new project, existing system, and migration scenarios. Use when asked to re-evaluate an AI SDLC framework, turn onboarding/onboard-lite artifacts into story panels, generate GPT image prompts, or build PPT/PPTX tutorials showing governance, architecture, subagents, commands, prompts, project-manifest.yml, and project-knowledge.yml gates.
---

# AI SDLC Framework Comic PPT

Use this skill to produce board-ready comic walkthrough decks for an AI SDLC
framework. The output is not a cartoon gimmick; it is an executive onboarding
artifact that makes framework decisions visible, repeatable, and agent-agnostic.

## Core Positioning

The framework is the operating model. Claude, Codex, GitHub Copilot, and future
assistants are execution layers.

Every scenario must show:

```text
Situation -> Decision -> AI SDLC Artifact -> Manifest Gate -> Outcome
```

Do not present vague abstraction alone. When a panel says "governance",
"architecture", "context", or "agent onboarding", show the concrete artifact
that carries it, especially `project-manifest.yml` and `project-knowledge.yml`.

## When Starting

1. Re-evaluate the local AI SDLC framework before creating slides.
2. Identify current artifacts: governance, architecture, onboarding/onboard-lite,
   subagents, commands, prompts, evaluations, release gates, templates.
3. Map artifacts to concrete onboarding gates.
4. Generate one scenario deck or a three-scenario pack:
   - New Project
   - Existing System
   - Migration Project
5. Use AI-generated panel images with editable PowerPoint text overlays.

## Framework Re-Evaluation Checklist

Before writing the comic, inspect the framework and produce a short gap list:

- What artifacts exist?
- Which artifacts are mandatory vs optional?
- Where does onboarding/onboard-lite create `project-manifest.yml`?
- Where does it create or update `project-knowledge.yml`?
- Which gates update the manifest?
- Which agent tools are supported without changing the framework?
- Which decisions are enforceable by files, checklists, or commands?
- Which parts still sound abstract and need a concrete artifact anchor?

If an artifact is missing, do not invent that it exists. Mark it as a
recommended addition and design the slide as "recommended framework upgrade".

## Required Deck Structure

Default deck for each scenario: 6-7 slides.

1. **Scenario cover**: audience, business problem, agent-agnostic promise.
2. **Problem room**: team discusses the problem statement before tools.
3. **Decision conflict**: pressure to move fast vs governance/risk reality.
4. **Framework entry**: AI SDLC gates and concrete artifacts appear.
5. **Manifest gate walkthrough**: show `project-manifest.yml` as the control plane.
6. **Execution panels**: subagents, prompts, commands, architecture, evidence gates.
7. **Outcome and POC**: measurable outcome and when to contact the framework owner.

For a shorter executive version, use 5 slides by merging slides 5 and 6.

## Manifest-First Rule

When the audience might hear "abstraction", make the framework tangible:

- show `project-manifest.yml` snapshots or YAML excerpts at each gate;
- show `project-knowledge.yml` as the shared context memory;
- show gate status changing from `draft` to `approved` to `evidence-linked`;
- show links to ADRs, risk notes, prompt packs, command catalogs, and subagents;
- show that the manifest is the handoff contract across agents and teams.

Preferred wording:

```text
The framework is not an abstraction layer over tools.
It is a manifest-driven SDLC control plane for governed AI-assisted delivery.
```

## Scenario References

Load only the needed reference files:

- `references/scenario-blueprints.md`: panel flows for new project, existing system, migration.
- `references/artifact-gates.md`: manifest-first onboarding gates and artifact matrix.
- `references/image-generation.md`: GPT image prompt patterns, including `gpt-image-2`.
- `references/deck-quality.md`: enterprise presentation quality bar and review checklist.

Use assets as copyable starting points:

- `assets/scenario-spec.template.yml`
- `assets/project-manifest.gate-examples.yml`

## Image Generation Rules

Use generated images for panel art, but keep all readable business text in PPT.

Panel art constraints:

- no company logos or vendor marks;
- no readable UI text inside images;
- no watermark;
- no childish cartoon style;
- no fake brand identity;
- consistent cast and setting;
- empty visual space for editable speech bubbles.

If GPT image generation is available, prefer `gpt-image-2` when the environment
supports it. If the local image tool supports only another model, use the best
available model and record the model used.

## PowerPoint Rules

- Use 16:9 widescreen.
- Use AI images as panel backgrounds.
- Add speech bubbles, captions, YAML snippets, and labels as editable PPT shapes.
- Use no more than two dialogue bubbles per panel.
- Keep each bubble under 16 words when possible.
- Include a small artifact label per panel, for example:
  `Gate 2 -> project-manifest.yml:risk_classification`.
- Use restrained enterprise colors, not bright comic colors.

## POC Slide

End every scenario with a professional POC positioning slide:

```text
Engage the AI SDLC Framework POC before starting or scaling AI-assisted delivery.
```

List concrete services:

- use-case classification;
- onboarding/onboard-lite path;
- manifest and knowledge setup;
- governance and architecture gate alignment;
- agent/tool selection guidance;
- prompt, command, and subagent enablement;
- evidence gate and release readiness review.

Avoid self-promotional wording. Make ownership sound operational and useful.

## Deliverables

For a complete run, produce:

- framework re-evaluation notes;
- scenario spec YAML;
- image prompt JSONL or prompt list;
- generated panel images/contact sheet;
- editable PPTX deck(s);
- short review summary with remaining gaps.

Validate that the PPTX opens, slide count is correct, generated images are
embedded, and all business text is editable.
