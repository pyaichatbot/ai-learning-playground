# Deck Quality

Use this reference before finalizing PPTX output.

## Enterprise Quality Bar

The deck should look like a serious internal transformation artifact, not a
novelty comic.

A slide is ready only if:

- the decision is clear in 10 seconds;
- the framework artifact is concrete and visible;
- the manifest gate is named where relevant;
- the text is editable in PowerPoint;
- the image has no vendor logos or fake brand marks;
- the tone is credible for senior engineering, architecture, and risk leaders;
- the framework is the hero, not a specific coding agent.

## Visual System

Recommended palette:

```text
Ink: #171F2A
Paper: #F4F1EA
Enterprise blue: #365B96
Teal: #2C7C82
Burgundy: #7C394C
Gold: #CD9A4E
Warm accent: #BE7448
Muted text: #5A6370
```

Rules:

- use 16:9 widescreen;
- use panel borders in ink;
- use editable speech bubbles;
- keep captions short;
- use small artifact labels;
- avoid emojis;
- avoid hero-metric hype unless measured and sourced;
- avoid real company logos unless the user provides approved assets.

## Slide Types

Use a varied but disciplined rhythm:

- cover with one strong panel;
- 2x2 comic panel slide;
- manifest gate slide with panel + YAML card;
- artifact map slide;
- outcome/POC slide.

## POC Positioning

Use operational ownership language:

```text
Engage the AI SDLC Framework POC before starting or scaling AI-assisted delivery.
```

Avoid:

- "I am the only person who can approve this";
- "single point of control";
- political or self-promotional language.

Prefer:

```text
Single POC for AI SDLC framework enablement, governance alignment,
artifact readiness, and agent-agnostic delivery patterns.
```

## Final Verification

Before final response:

- open/parse PPTX to confirm slide count;
- confirm generated image files exist;
- confirm business text is in PPT shapes, not only embedded in images;
- create a contact sheet if images were generated;
- list any framework gaps found during re-evaluation.
