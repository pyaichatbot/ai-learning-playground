# Scenario Blueprints

Use these flows to generate scenario specs and panel prompts.

## Shared Cast

Keep roles consistent across all scenarios:

- Product Owner / PM: frames business outcome.
- AI Architect: maps framework, architecture, and agent boundaries.
- Engineering Lead: owns implementation, tests, and commands.
- Risk/Governance Stakeholder: enforces audit, approval, and release gates.
- Business Sponsor: appears on outcome/POC slide when needed.

## Scenario 1: New Project

Theme: unclear requirements, data uncertainty, structured intake.

Panel flow:

1. Business sponsor introduces a new AI-assisted delivery idea.
2. Engineer suggests starting with a coding assistant.
3. Risk stakeholder asks what data, users, and approvals are involved.
4. AI Architect opens onboarding/onboard-lite decision.
5. `project-manifest.yml` is created with owner, scenario, risk, allowed agents.
6. `project-knowledge.yml` captures domain context and constraints.
7. Team selects agent/tool path only after gates are clear.
8. Outcome: project starts with traceable decisions and reusable artifacts.

Recommended slide claim:

```text
New AI-assisted projects start faster when intake and context are explicit.
```

## Scenario 2: Existing System

Theme: model or software already in production, drift/monitoring gaps,
governance catch-up.

Panel flow:

1. Existing system already uses AI or agent-generated changes.
2. Incident, drift, monitoring gap, or ownership confusion appears.
3. Team realizes prompts/changes exist outside a governed SDLC path.
4. Framework assessment maps current state to gates.
5. `project-manifest.yml` records system criticality, owners, evidence gaps.
6. `project-knowledge.yml` captures current architecture and operational facts.
7. Evidence gates add monitoring, evals, reviews, and release controls.
8. Outcome: existing system becomes governed without stopping delivery.

Recommended slide claim:

```text
Existing systems do not need to pause; they need a manifest-backed control path.
```

## Scenario 3: Migration Project

Theme: legacy system, technical debt, incremental modernization.

Panel flow:

1. Team discusses legacy monolith delay and migration pressure.
2. Engineer proposes using coding agents to accelerate rewrite.
3. Risk stakeholder blocks tool-first adoption until governance is clear.
4. AI Architect maps migration domains, dependencies, and data flows.
5. `project-manifest.yml` selects migration slice, risk class, approvals.
6. Agent/subagent model is chosen for planning, tests, refactor, review.
7. Evidence gate requires tests, architecture review, risk notes, rollback.
8. Outcome: measured modernization with traceable AI-assisted delivery.

Recommended slide claim:

```text
Migration becomes safer when the manifest controls scope, risk, evidence, and agent boundaries.
```

## Dialogue Rules

Use short, realistic lines:

- "The monolith is now a delivery risk."
- "Do not choose the agent before the gate."
- "The manifest shows who owns the decision."
- "The assistant prepares evidence; the team decides."
- "No release until the manifest links the proof."

Avoid:

- long explanations in speech bubbles;
- command syntax in speech bubbles;
- tool fandom;
- claims like "10x" unless sourced by the user.

## Scenario Pack Structure

If generating all three scenarios, create:

- one overview deck with the common operating model;
- one scenario deck per use case; or
- one combined 18-21 slide deck if the user needs a single walkthrough.

For senior leadership, prefer the overview + migration scenario first.
