# Production‑grade AI Governance Skill

This package provides a **production‑ready** AI governance skill for
software development life cycle (SDLC) integration.  It expands the
earlier prototype by incorporating comprehensive risk dimensions from
the TÜV AI Assessment Matrix【107994856721055†L1320-L1372】, agentic AI
risks identified in UC Berkeley’s Agentic AI Risk‑Management Standards
Profile【248379492549668†L240-L254】, process controls (Govern, Map,
Measure, Manage)【248379492549668†L100-L144】【248379492549668†L145-L170】,
and recent legal scholarship on EU compliance for AI agents【452632958028449†L63-L72】.
The result is a set of artefacts suitable for integration into your
organisation’s AI SDLC tooling and pipelines.

## What’s inside

* **`risk_evaluation_rules.yaml`**: A comprehensive set of risk
  dimensions grouped into *core*, *agentic* and *process* sections.
  Each dimension has a weight and descriptive text.  These rules
  cover autonomy, safety, explainability, data protection, fairness,
  sustainability, agentic behaviours (unintended goal pursuit,
  privilege escalation, external tool integration, environmental
  interaction, behavioural drift, oversight evasion) and governance
  processes.  The dimensions are directly grounded in recognised
  frameworks【107994856721055†L1320-L1372】【248379492549668†L240-L254】.

* **`regulatory_mapping.yaml`**: A mapping between risk categories and
  obligations.  It includes EU AI Act Articles 9–15 for high‑risk
  systems【922660114373648†L74-L109】 and supplements them with agentic‑specific
  obligations such as least‑privilege design, behavioural drift
  monitoring and action inventory【452632958028449†L63-L72】.  Use this
  mapping to generate compliance requirements beyond the AI Act when
  dealing with agentic systems.

* **`evaluate_ai_system.py`**: A production‑grade evaluation engine.
  It flattens nested rule definitions, computes a normalised risk
  fraction, assigns a risk category (high/medium/low), and produces a
  structured report.  If the system YAML sets `agentic: true`, the
  script appends additional agentic obligations from the mapping file.
  The thresholds and weights are configurable by editing the YAML files.

* **`ai_system_example.yaml`**: An example description for a credit
  decision agent.  It demonstrates how to assign scores for every
  dimension, flag high‑risk domains and agentic behaviour.

## Why this is production grade

1. **Comprehensive coverage**: The rules combine technical
   characteristics from the TÜV matrix with agentic risks (goal
   alignment, privilege escalation, behavioural drift etc.) and
   organisational process controls.  This breadth ensures that the
   evaluation captures both system‑level and organisational factors.

2. **Extensible and configurable**: Weights and thresholds are
   externalised in YAML.  You can tune them without touching the
   evaluation engine.  Additional dimensions can be added as new
   standards emerge.

3. **Agentic awareness**: By including an `agentic` flag and
   agentic‑specific obligations, the skill addresses the unique
   challenges of AI agents highlighted by regulators and researchers
   【248379492549668†L240-L254】【452632958028449†L63-L72】.

4. **Process integration**: The process control dimensions map
   directly to the Govern/Map/Measure/Manage functions from the
   Agentic AI Profile, encouraging the adoption of continuous
   risk management practices rather than one‑off audits【248379492549668†L100-L144】【248379492549668†L145-L170】.

5. **Regulatory mapping**: The mapping file not only links to EU AI
   Act obligations but also highlights additional agentic controls
   discussed in recent legal scholarship【452632958028449†L63-L72】.  This
   helps teams plan compliance beyond the AI Act (e.g. GDPR, Cyber
   Resilience Act).

## Integration guidance

To embed this skill into your AI SDLC, follow these steps:

1. **Install dependencies**: The evaluation engine requires Python and
   PyYAML.  Install them via:

   ```bash
   pip install pyyaml
   ```

2. **Tailor the rules**: Review `risk_evaluation_rules.yaml` and
   adjust weights or add dimensions to reflect your organisation’s
   risk appetite and sector‑specific requirements.

3. **Describe your systems**: Create a YAML file for each AI system
   capturing its name, domain, description, flags (`high_risk_domain`,
   `agentic`) and scores for all defined dimensions.  Use the
   example as a template.

4. **Run evaluation**: Invoke the script from your CI pipeline or
   agent skill framework:

   ```bash
   python evaluate_ai_system.py \
       --system your_system.yaml \
       --rules risk_evaluation_rules.yaml \
       --mapping regulatory_mapping.yaml \
       --output your_report.yaml
   ```

   Incorporate the resulting report into your model cards, decision
   logs or pipeline gating logic.  For high‑risk or agentic systems,
   ensure that all listed obligations are addressed before deployment.

5. **Embed in coding agents**: Package `evaluate_ai_system.py` and
   the YAML files as a skill callable from your development assistants
   (e.g. GitHub Copilot for AI, Claude agents).  When developers
   modify code or system configuration, the assistant can call the
   skill with the updated YAML to provide real‑time feedback on
   compliance status.

By following these steps, you can move from a proof‑of‑concept to a
robust AI governance layer embedded throughout your SDLC.