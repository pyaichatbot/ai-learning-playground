"""
evaluate_ai_system.py (production‑grade)
=======================================

This script evaluates AI systems using the comprehensive risk rules and
regulatory mapping defined in this package.  It supports nested
categories and agentic AI flags, computes a normalised risk score and
determines whether the system falls into high, medium or low risk.  For
agentic systems it also outputs additional obligations derived from
contemporary agentic AI guidance【248379492549668†L240-L254】【452632958028449†L63-L72】.

Usage::

    python evaluate_ai_system.py --system PATH_TO_AI_SYSTEM_YAML \
                                 [--rules risk_evaluation_rules.yaml] \
                                 [--mapping regulatory_mapping.yaml] \
                                 [--output report.yaml]

The AI system YAML must include a `dimensions` mapping with scores
between 0 and 5 for each dimension defined in the rules.  It may
optionally include `high_risk_domain: true` if the system falls under
Annex III and an `agentic: true` flag if the system implements agentic
capabilities (multi‑step planning, external tool invocation, etc.).
"""

import argparse
import json
import os
from pathlib import Path
from typing import Dict, Any

try:
    import yaml  # type: ignore
except ImportError:
    raise SystemExit("Please install PyYAML (pip install pyyaml) to run this script.")


def load_yaml(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def flatten_rules(rules: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """
    Flatten the nested rules dictionary into a single mapping of dimension
    names to their metadata (description and weight).
    """
    flat: Dict[str, Dict[str, Any]] = {}
    for category_key in ["core_dimensions", "agentic_dimensions", "process_controls"]:
        category = rules.get(category_key, {})
        for dim, meta in category.items():
            flat[dim] = meta
    return flat


def compute_risk_score(system_data: Dict[str, Any], flat_rules: Dict[str, Any]) -> float:
    """Compute normalised risk fraction using all dimensions defined in flat_rules."""
    dimensions_scores = system_data.get("dimensions", {})
    total_score = 0.0
    max_score = 0.0
    for dim, meta in flat_rules.items():
        weight = float(meta.get("weight", 1))
        max_score += weight * 5
        score = float(dimensions_scores.get(dim, 0))
        if score < 0:
            score = 0.0
        elif score > 5:
            score = 5.0
        total_score += score * weight
    return 0.0 if max_score == 0 else total_score / max_score


def determine_risk_category(system_data: Dict[str, Any], risk_fraction: float) -> str:
    """
    Determine risk category.  If high_risk_domain flag is set, always
    return 'high'.  Otherwise use thresholds 0.6 and 0.3.
    """
    if system_data.get("high_risk_domain", False):
        return "high"
    if risk_fraction >= 0.6:
        return "high"
    elif risk_fraction >= 0.3:
        return "medium"
    else:
        return "low"


def build_report(system_data: Dict[str, Any], risk_fraction: float, category: str,
                 mapping: Dict[str, Any]) -> Dict[str, Any]:
    """
    Construct a structured report.  Include agentic obligations if
    `agentic` flag is true and such obligations are defined for the category.
    """
    risk_map = mapping.get("risk_categories", {}).get(category, {})
    obligations = risk_map.get("obligations", [])
    report: Dict[str, Any] = {
        "name": system_data.get("name"),
        "description": system_data.get("description"),
        "domain": system_data.get("domain"),
        "agentic": bool(system_data.get("agentic", False)),
        "high_risk_domain": bool(system_data.get("high_risk_domain", False)),
        "risk_fraction": round(risk_fraction, 3),
        "risk_category": category,
        "classification": risk_map.get("classification"),
        "obligations": obligations,
    }
    if system_data.get("agentic", False):
        # append agentic obligations if present
        agentic_obs = risk_map.get("agentic_obligations", [])
        report["agentic_obligations"] = agentic_obs
    return report


def print_summary(report: Dict[str, Any]) -> None:
    print("\nAI System Risk Evaluation Summary (Production‑grade)")
    print("=" * 50)
    print(f"Name: {report.get('name')}")
    if report.get('description'):
        # print a truncated description for readability
        desc_lines = report['description'].splitlines()
        for line in desc_lines:
            if line.strip():
                print(f"Description: {line.strip()}")
                break
    print(f"Domain: {report.get('domain')}")
    print(f"Agentic: {report.get('agentic')}")
    print(f"High‑risk domain flag: {report.get('high_risk_domain')}")
    print(f"Risk score (0–1): {report.get('risk_fraction')}")
    print(f"Risk category: {report.get('risk_category')} ({report.get('classification')})")

    if report.get('obligations'):
        print("\nEU AI Act obligations (core):")
        for ob in report['obligations']:
            print(f"  - Article {ob.get('article')}: {ob.get('name')}")
    else:
        print("\nNo core obligations apply under the AI Act.")

    if report.get('agentic_obligations'):
        print("\nAdditional obligations for agentic AI:")
        for ob in report['agentic_obligations']:
            print(f"  - {ob.get('name')}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate AI systems for risk and generate compliance guidance.")
    parser.add_argument("--system", required=True, help="Path to AI system YAML description.")
    parser.add_argument("--rules", default="risk_evaluation_rules.yaml", help="Path to risk evaluation rules YAML.")
    parser.add_argument("--mapping", default="regulatory_mapping.yaml", help="Path to regulatory mapping YAML.")
    parser.add_argument("--output", help="Optional path to save report YAML.")
    args = parser.parse_args()

    system_path = Path(args.system)
    rules_path = Path(args.rules)
    mapping_path = Path(args.mapping)

    if not system_path.exists():
        raise SystemExit(f"System file not found: {system_path}")
    if not rules_path.exists():
        raise SystemExit(f"Rules file not found: {rules_path}")
    if not mapping_path.exists():
        raise SystemExit(f"Mapping file not found: {mapping_path}")

    system_data = load_yaml(system_path)
    rules = load_yaml(rules_path)
    mapping = load_yaml(mapping_path)

    flat_rules = flatten_rules(rules)
    risk_fraction = compute_risk_score(system_data, flat_rules)
    category = determine_risk_category(system_data, risk_fraction)
    report = build_report(system_data, risk_fraction, category, mapping)

    print_summary(report)

    if args.output:
        output_path = Path(args.output)
        with output_path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(report, f)
        print(f"\nReport saved to {output_path}")


if __name__ == "__main__":
    main()